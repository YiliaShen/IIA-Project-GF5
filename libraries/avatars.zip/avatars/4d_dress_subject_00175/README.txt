4D-Dress Subject 00175

Loadable avatar files are under outputs/.
outputs/animation_lowres.obj is the GF5 SMPL-24 neutral-bind animation mesh.
outputs/animation_lowres_skinning_weights.npz stores SMPL-24 skinning weights for the animation mesh.
outputs/smplx_mesh.obj is the canonicalized fitted SMPL-X body reference.
Skinning contract version: 5. Coordinates: up2you_smpl_native_y_up.
GF5 viewers apply the native-to-viewer axis conversion once when loading.
preview.png is a compact contact-sheet view of the prepared reference character.
