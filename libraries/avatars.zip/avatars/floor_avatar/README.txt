Dark brown thin floor avatar.
Loadable avatar files are under outputs/.
animation_lowres.obj and smplx_mesh.obj are the floor mesh.
animation_lowres_skinning_weights.npz binds all vertices to the root joint.
