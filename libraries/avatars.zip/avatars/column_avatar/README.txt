Root-bound Column Avatar

Loadable avatar files are under outputs/.
outputs/animation_lowres.obj is the GF5 SMPL-24 neutral-bind animation mesh.
outputs/animation_lowres_skinning_weights.npz stores SMPL-24 skinning weights for the animation mesh.
outputs/smplx_mesh.obj is the canonicalized fitted SMPL-X body reference.
This avatar is a simple rectangular column, bound 100% to the root joint.
